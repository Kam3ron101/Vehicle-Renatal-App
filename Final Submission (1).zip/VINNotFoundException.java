
public class VINNotFoundException extends Exception {

}
